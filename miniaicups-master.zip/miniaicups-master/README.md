# miniaicups
Правила, исходники и прочее для aicups.ru

## [Paper IO](paperio/)
