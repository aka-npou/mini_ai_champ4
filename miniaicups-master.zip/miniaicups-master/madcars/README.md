# MadCars

Чемпионат проходит с 30 августа 2018 года по 26 сентября 2018 года включительно на сайте [aicups.ru](http://aicups.ru/).  
Официальный анонс чемпионата - [Хабр](https://habr.com/company/mailru/blog/421397/).  
Официальная группа в telegram - [@aicups](https://t.me/aicups).  
Официальный telegram-канал - [@mrgchamps](https://t.me/mrgchamps).  
Неофициальный telegram-канал - [@ai_cups_unofficial](https://t.me/ai_cups_unofficial).  

## [Правила чемпионата](RULES.md)

## [Быстрый старт](QUICKSTART.md)

## [Набор docker-файлов для используемых языков](dockers/)
