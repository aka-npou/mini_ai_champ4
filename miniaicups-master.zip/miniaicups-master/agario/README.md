# Agar IO

Чемпионат проходит с 28 марта по 26 апреля включительно на сайте [aicups.ru](http://aicups.ru/).  
Официальный анонс чемпионата - [https://habrahabr.ru/company/mailru/blog/351522/](https://habrahabr.ru/company/mailru/blog/351522/).  
Официальная группа в telegram - [@aicups](https://t.me/aicups).  
Официальный telegram-канал - [@mrgchamps](https://t.me/mrgchamps).  
Неофициальный telegram-канал - [@ai_cups_unofficial](https://t.me/ai_cups_unofficial).  

## [Правила чемпионата](RULES.md)

## [Набор docker-файлов для используемых языков](dockers/)
