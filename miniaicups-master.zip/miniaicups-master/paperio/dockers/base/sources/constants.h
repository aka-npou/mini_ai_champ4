#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <QVector>
#include <QString>
#include <QDebug>
#include <QByteArray>

const int PORT = 8000;
const int MAX_RESP_LEN = 10000;


#endif // CONSTANTS_H
